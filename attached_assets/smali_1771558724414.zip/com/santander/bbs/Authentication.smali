.class public Lcom/santander/bbs/Authentication;
.super Landroid/os/AsyncTask;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/String;",
        "Ljava/lang/Void;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# static fields
.field private static final TAG:Ljava/lang/String; = "AuthenticationTask"


# instance fields
.field private final pDialog:Landroid/app/Dialog;

.field private puk:[B

.field public rdToken:Ljava/lang/String;

.field public user:Ljava/lang/String;

.field private final weakReference:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcom/santander/bbs/MainActivity;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/santander/bbs/MainActivity;)V
    .registers 6

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    const/16 v0, 0xa2

    new-array v0, v0, [B

    fill-array-data v0, :array_4c

    iput-object v0, p0, Lcom/santander/bbs/Authentication;->puk:[B

    const-string v0, ""

    iput-object v0, p0, Lcom/santander/bbs/Authentication;->user:Ljava/lang/String;

    iput-object v0, p0, Lcom/santander/bbs/Authentication;->rdToken:Ljava/lang/String;

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/santander/bbs/Authentication;->weakReference:Ljava/lang/ref/WeakReference;

    new-instance v0, Landroid/widget/ProgressBar;

    invoke-direct {v0, p1}, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context;)V

    new-instance v1, Landroid/app/Dialog;

    invoke-direct {v1, p1}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lcom/santander/bbs/Authentication;->pDialog:Landroid/app/Dialog;

    iget-object v1, p0, Lcom/santander/bbs/Authentication;->pDialog:Landroid/app/Dialog;

    invoke-virtual {v1, v0}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    iget-object v1, p0, Lcom/santander/bbs/Authentication;->pDialog:Landroid/app/Dialog;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->setCancelable(Z)V

    iget-object v1, p0, Lcom/santander/bbs/Authentication;->pDialog:Landroid/app/Dialog;

    invoke-virtual {v1, v2}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    iget-object v1, p0, Lcom/santander/bbs/Authentication;->pDialog:Landroid/app/Dialog;

    invoke-virtual {v1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    if-eqz v1, :cond_4b

    iget-object v1, p0, Lcom/santander/bbs/Authentication;->pDialog:Landroid/app/Dialog;

    invoke-virtual {v1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    new-instance v3, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v3, v2}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v1, v3}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_4b
    return-void

    :array_4c
    .array-data 1
        0x30t
        -0x7ft
        -0x61t
        0x30t
        0xdt
        0x6t
        0x9t
        0x2at
        -0x7at
        0x48t
        -0x7at
        -0x9t
        0xdt
        0x1t
        0x1t
        0x1t
        0x5t
        0x0t
        0x3t
        -0x7ft
        -0x73t
        0x0t
        0x30t
        -0x7ft
        -0x77t
        0x2t
        -0x7ft
        -0x7ft
        0x0t
        -0x22t
        -0x19t
        -0x6et
        -0x6at
        -0x51t
        0x21t
        -0x23t
        0x29t
        -0x55t
        -0x53t
        -0x31t
        -0x77t
        -0x76t
        0x4bt
        0x6ft
        -0x79t
        0x9t
        -0x1dt
        -0x18t
        0x6ct
        0x1bt
        -0x70t
        -0x1dt
        0x3at
        -0x3ft
        0x22t
        0x1et
        0x2ct
        0x35t
        -0x46t
        0xdt
        0x38t
        -0x52t
        -0x73t
        -0xet
        -0x71t
        0x25t
        0xdt
        -0x61t
        0x5ct
        -0x1ct
        0x1dt
        0x52t
        0xct
        0x52t
        -0x6et
        0x2et
        0x18t
        -0x39t
        -0x6dt
        -0x5ct
        -0x1bt
        -0x2ft
        -0x25t
        -0x6ct
        -0x36t
        0x2t
        0x65t
        -0x64t
        0x1t
        0x7dt
        0x40t
        -0x6ft
        0x54t
        0x17t
        -0x7at
        0x1ct
        -0x2dt
        -0x27t
        0x33t
        -0x1bt
        0x40t
        0x1t
        0x78t
        0x4dt
        -0x6bt
        0x6at
        0x63t
        -0x52t
        0x3dt
        0x71t
        0x0t
        0x7dt
        -0x3at
        0x70t
        -0x34t
        -0x64t
        0x1t
        -0x23t
        -0x72t
        -0x6et
        -0x25t
        -0x11t
        -0x37t
        -0x34t
        -0x65t
        0x53t
        0x49t
        0x6bt
        -0x47t
        0x3dt
        0x39t
        -0x15t
        0x7bt
        0x6ct
        -0x63t
        0x4et
        0x3at
        -0x7dt
        0x50t
        -0x7ft
        -0x1dt
        -0x70t
        0x16t
        -0x14t
        0x59t
        0x39t
        -0x22t
        -0x15t
        -0x40t
        -0x66t
        -0x16t
        0x5dt
        0x5at
        0x5bt
        -0x22t
        0x5ft
        0x1dt
        0x2t
        0x3t
        0x1t
        0x0t
        0x1t
    .end array-data
.end method

.method public static createFolderAndFile(Landroid/content/Context;)V
    .registers 12

    new-instance v0, Ljava/io/File;

    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v1

    const-string v2, "Origin"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    const-string v2, "AuthenticationTask"

    if-nez v1, :cond_1f

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    move-result v1

    if-nez v1, :cond_1f

    const-string v1, "Erro ao criar a pasta \'Origin\'"

    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_1f
    new-instance v1, Ljava/io/File;

    const-string v3, "check.dat"

    invoke-direct {v1, v0, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v3

    const-string v4, "Arquivo criado."

    const/4 v5, 0x0

    const-string v6, "Erro ao criar o arquivo \'check.dat\'"

    if-nez v3, :cond_59

    :try_start_31
    new-instance v3, Ljava/io/FileWriter;

    invoke-direct {v3, v1}, Ljava/io/FileWriter;-><init>(Ljava/io/File;)V
    :try_end_36
    .catch Ljava/io/IOException; {:try_start_31 .. :try_end_36} :catch_55

    :try_start_36
    invoke-virtual {v3, v4}, Ljava/io/FileWriter;->write(Ljava/lang/String;)V
    :try_end_39
    .catch Ljava/lang/Throwable; {:try_start_36 .. :try_end_39} :catch_40
    .catchall {:try_start_36 .. :try_end_39} :catchall_3d

    :try_start_39
    invoke-virtual {v3}, Ljava/io/FileWriter;->close()V
    :try_end_3c
    .catch Ljava/io/IOException; {:try_start_39 .. :try_end_3c} :catch_55

    goto :goto_59

    :catchall_3d
    move-exception v7

    move-object v8, v5

    goto :goto_46

    :catch_40
    move-exception v7

    :try_start_41
    throw v7
    :try_end_42
    .catchall {:try_start_41 .. :try_end_42} :catchall_42

    :catchall_42
    move-exception v8

    move-object v10, v8

    move-object v8, v7

    move-object v7, v10

    :goto_46
    if-eqz v8, :cond_51

    :try_start_48
    invoke-virtual {v3}, Ljava/io/FileWriter;->close()V
    :try_end_4b
    .catch Ljava/lang/Throwable; {:try_start_48 .. :try_end_4b} :catch_4c
    .catch Ljava/io/IOException; {:try_start_48 .. :try_end_4b} :catch_55

    goto :goto_54

    :catch_4c
    move-exception v9

    :try_start_4d
    invoke-virtual {v8, v9}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    goto :goto_54

    :cond_51
    invoke-virtual {v3}, Ljava/io/FileWriter;->close()V

    :goto_54
    throw v7
    :try_end_55
    .catch Ljava/io/IOException; {:try_start_4d .. :try_end_55} :catch_55

    :catch_55
    move-exception v3

    invoke-static {v2, v6, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_59
    :goto_59
    new-instance v3, Ljava/io/File;

    const-string v7, ".lib"

    invoke-direct {v3, v0, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v7

    if-nez v7, :cond_89

    :try_start_66
    new-instance v7, Ljava/io/FileWriter;

    invoke-direct {v7, v3}, Ljava/io/FileWriter;-><init>(Ljava/io/File;)V
    :try_end_6b
    .catch Ljava/io/IOException; {:try_start_66 .. :try_end_6b} :catch_85

    :try_start_6b
    invoke-virtual {v7, v4}, Ljava/io/FileWriter;->write(Ljava/lang/String;)V
    :try_end_6e
    .catch Ljava/lang/Throwable; {:try_start_6b .. :try_end_6e} :catch_74
    .catchall {:try_start_6b .. :try_end_6e} :catchall_72

    :try_start_6e
    invoke-virtual {v7}, Ljava/io/FileWriter;->close()V
    :try_end_71
    .catch Ljava/io/IOException; {:try_start_6e .. :try_end_71} :catch_85

    goto :goto_89

    :catchall_72
    move-exception v4

    goto :goto_76

    :catch_74
    move-exception v5

    :try_start_75
    throw v5
    :try_end_76
    .catchall {:try_start_75 .. :try_end_76} :catchall_72

    :goto_76
    if-eqz v5, :cond_81

    :try_start_78
    invoke-virtual {v7}, Ljava/io/FileWriter;->close()V
    :try_end_7b
    .catch Ljava/lang/Throwable; {:try_start_78 .. :try_end_7b} :catch_7c
    .catch Ljava/io/IOException; {:try_start_78 .. :try_end_7b} :catch_85

    goto :goto_84

    :catch_7c
    move-exception v8

    :try_start_7d
    invoke-virtual {v5, v8}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    goto :goto_84

    :cond_81
    invoke-virtual {v7}, Ljava/io/FileWriter;->close()V

    :goto_84
    throw v4
    :try_end_85
    .catch Ljava/io/IOException; {:try_start_7d .. :try_end_85} :catch_85

    :catch_85
    move-exception v4

    invoke-static {v2, v6, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_89
    :goto_89
    return-void
.end method

.method private encrypt(Ljava/lang/String;[B)Ljava/lang/String;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const-string v0, "RSA/ECB/PKCS1Padding"

    invoke-static {v0}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object v0

    invoke-direct {p0, p2}, Lcom/santander/bbs/Authentication;->getPublicKey([B)Ljava/security/PublicKey;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v0, v2, v1}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;)V

    sget-object v1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p1, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v1

    invoke-virtual {v0, v1}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object v1

    invoke-static {v1}, Lcom/santander/bbs/Utils;->toBase64([B)Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method private getActivity()Lcom/santander/bbs/MainActivity;
    .registers 2

    iget-object v0, p0, Lcom/santander/bbs/Authentication;->weakReference:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/santander/bbs/MainActivity;

    return-object v0
.end method

.method public static getAppUID(Landroid/content/Context;)Ljava/lang/String;
    .registers 6

    nop

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string v1, "android_id"

    invoke-static {v0, v1}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const-string v2, "LKTEAM_APP_UID"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ":"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/santander/bbs/Authentication;->sha256(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    return-object v4
.end method

.method private getDeviceName()Ljava/lang/String;
    .registers 5

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    sget-object v1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_b

    return-object v1

    :cond_b
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    return-object v2
.end method

.method public static getPublicIpAddress()Ljava/lang/String;
    .registers 6

    :try_start_0
    new-instance v0, Ljava/net/URL;

    const-string v1, "https://api.ipify.org"

    invoke-direct {v0, v1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v1

    check-cast v1, Ljavax/net/ssl/HttpsURLConnection;

    const/16 v2, 0x1388

    invoke-virtual {v1, v2}, Ljavax/net/ssl/HttpsURLConnection;->setConnectTimeout(I)V

    invoke-virtual {v1, v2}, Ljavax/net/ssl/HttpsURLConnection;->setReadTimeout(I)V

    new-instance v2, Ljava/io/BufferedReader;

    new-instance v3, Ljava/io/InputStreamReader;

    invoke-virtual {v1}, Ljavax/net/ssl/HttpsURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v2, v3}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_23
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_23} :catch_3f

    const/4 v3, 0x0

    :try_start_24
    invoke-virtual {v2}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v3
    :try_end_28
    .catch Ljava/lang/Throwable; {:try_start_24 .. :try_end_28} :catch_2e
    .catchall {:try_start_24 .. :try_end_28} :catchall_2c

    :try_start_28
    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_2b
    .catch Ljava/lang/Exception; {:try_start_28 .. :try_end_2b} :catch_3f

    return-object v3

    :catchall_2c
    move-exception v4

    goto :goto_30

    :catch_2e
    move-exception v3

    :try_start_2f
    throw v3
    :try_end_30
    .catchall {:try_start_2f .. :try_end_30} :catchall_2c

    :goto_30
    if-eqz v3, :cond_3b

    :try_start_32
    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_35
    .catch Ljava/lang/Throwable; {:try_start_32 .. :try_end_35} :catch_36
    .catch Ljava/lang/Exception; {:try_start_32 .. :try_end_35} :catch_3f

    goto :goto_3e

    :catch_36
    move-exception v5

    :try_start_37
    invoke-virtual {v3, v5}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    goto :goto_3e

    :cond_3b
    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V

    :goto_3e
    throw v4
    :try_end_3f
    .catch Ljava/lang/Exception; {:try_start_37 .. :try_end_3f} :catch_3f

    :catch_3f
    move-exception v0

    const-string v1, "AuthenticationTask"

    const-string v2, "Não foi possível obter o IP público."

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const-string v0, "Unavailable"

    return-object v0
.end method

.method private getPublicKey([B)Ljava/security/PublicKey;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    new-instance v0, Ljava/security/spec/X509EncodedKeySpec;

    invoke-direct {v0, p1}, Ljava/security/spec/X509EncodedKeySpec;-><init>([B)V

    const-string v1, "RSA"

    invoke-static {v1}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;)Ljava/security/KeyFactory;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/security/KeyFactory;->generatePublic(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;

    move-result-object v2

    return-object v2
.end method

.method private getUniqueId(Landroid/content/Context;)Ljava/lang/String;
    .registers 6

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-direct {p0}, Lcom/santander/bbs/Authentication;->getDeviceName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string v2, "android_id"

    invoke-static {v1, v2}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, ""

    const-string v2, " "

    invoke-virtual {v0, v2, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    sget-object v2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v2

    invoke-static {v2}, Ljava/util/UUID;->nameUUIDFromBytes([B)Ljava/util/UUID;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "-"

    invoke-virtual {v2, v3, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method public static native init(Ljava/lang/String;Ljava/lang/String;)V
.end method

.method private static isConnectionWithInternet(Landroid/content/Context;)Z
    .registers 5

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return v0

    :cond_4
    const-string v1, "connectivity"

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/net/ConnectivityManager;

    invoke-virtual {v1}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object v2

    if-eqz v2, :cond_19

    invoke-virtual {v2}, Landroid/net/NetworkInfo;->isConnected()Z

    move-result v3

    if-eqz v3, :cond_19

    const/4 v0, 0x1

    :cond_19
    return v0
.end method

.method static synthetic lambda$doInBackground$0(Ljava/lang/String;Ljavax/net/ssl/SSLSession;)Z
    .registers 3

    const/4 v0, 0x1

    return v0
.end method

.method private static sha256(Ljava/lang/String;)Ljava/lang/String;
    .registers 11

    :try_start_0
    const-string v0, "SHA-256"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    const-string v1, "UTF-8"

    invoke-virtual {p0, v1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    array-length v3, v1

    const/4 v4, 0x0

    const/4 v5, 0x0

    :goto_18
    if-ge v5, v3, :cond_32

    aget-byte v6, v1, v5

    const-string v7, "%02x"

    const/4 v8, 0x1

    new-array v8, v8, [Ljava/lang/Object;

    invoke-static {v6}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v9

    aput-object v9, v8, v4

    invoke-static {v7, v8}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    nop

    add-int/lit8 v5, v5, 0x1

    goto :goto_18

    :cond_32
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3
    :try_end_36
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_36} :catch_37

    return-object v3

    :catch_37
    move-exception v0

    const-string v1, "invalid"

    return-object v1
.end method

.method private verify(Ljava/lang/String;Ljava/lang/String;[B)Z
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const-string v0, "SHA256withRSA"

    invoke-static {v0}, Ljava/security/Signature;->getInstance(Ljava/lang/String;)Ljava/security/Signature;

    move-result-object v0

    invoke-direct {p0, p3}, Lcom/santander/bbs/Authentication;->getPublicKey([B)Ljava/security/PublicKey;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/security/Signature;->initVerify(Ljava/security/PublicKey;)V

    sget-object v1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p1, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/security/Signature;->update([B)V

    invoke-static {p2}, Lcom/santander/bbs/Utils;->fromBase64(Ljava/lang/String;)[B

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/security/Signature;->verify([B)Z

    move-result v1

    return v1
.end method


# virtual methods
.method protected bridge synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    check-cast p1, [Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/santander/bbs/Authentication;->doInBackground([Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected varargs doInBackground([Ljava/lang/String;)Ljava/lang/String;
    .registers 18

    move-object/from16 v1, p0

    const-string v2, "Falha na conexão"

    const-string v3, "AuthenticationTask"

    invoke-direct/range {p0 .. p0}, Lcom/santander/bbs/Authentication;->getActivity()Lcom/santander/bbs/MainActivity;

    move-result-object v4

    if-eqz v4, :cond_136

    invoke-static {v4}, Lcom/santander/bbs/Authentication;->isConnectionWithInternet(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_14

    goto/16 :goto_136

    :cond_14
    const/4 v0, 0x0

    :try_start_15
    aget-object v5, p1, v0

    iput-object v5, v1, Lcom/santander/bbs/Authentication;->user:Ljava/lang/String;

    const/4 v5, 0x1

    aget-object v6, p1, v5

    iput-object v6, v1, Lcom/santander/bbs/Authentication;->rdToken:Ljava/lang/String;

    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v6}, Lorg/json/JSONObject;-><init>()V

    new-instance v7, Lorg/json/JSONObject;

    invoke-direct {v7}, Lorg/json/JSONObject;-><init>()V

    const-string v8, "User_hk"

    iget-object v9, v1, Lcom/santander/bbs/Authentication;->user:Ljava/lang/String;

    invoke-virtual {v7, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v8, "Load_hk"

    const-string v9, "867"

    invoke-virtual {v7, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v8, "Uid_hk"

    invoke-direct {v1, v4}, Lcom/santander/bbs/Authentication;->getUniqueId(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-static {}, Lcom/santander/bbs/Authentication;->getPublicIpAddress()Ljava/lang/String;

    move-result-object v8

    const-string v9, "Ip_hk"

    if-eqz v8, :cond_49

    move-object v10, v8

    goto :goto_4b

    :cond_49
    const-string v10, "Unavailable"

    :goto_4b
    invoke-virtual {v7, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v9, "Dados_hk"

    invoke-virtual {v7}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v10

    iget-object v11, v1, Lcom/santander/bbs/Authentication;->puk:[B

    invoke-direct {v1, v10, v11}, Lcom/santander/bbs/Authentication;->encrypt(Ljava/lang/String;[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v6, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v9, "Hash_hk"

    invoke-virtual {v7}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Lcom/santander/bbs/Utils;->SHA256(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v6, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v9, "Tok_hk"

    iget-object v10, v1, Lcom/santander/bbs/Authentication;->rdToken:Ljava/lang/String;

    invoke-virtual {v6, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v9, v5, [Ljavax/net/ssl/TrustManager;

    new-instance v10, Lcom/santander/bbs/Authentication$1;

    invoke-direct {v10, v1}, Lcom/santander/bbs/Authentication$1;-><init>(Lcom/santander/bbs/Authentication;)V

    aput-object v10, v9, v0

    const-string v0, "TLS"

    invoke-static {v0}, Ljavax/net/ssl/SSLContext;->getInstance(Ljava/lang/String;)Ljavax/net/ssl/SSLContext;

    move-result-object v0

    move-object v10, v0

    new-instance v0, Ljava/security/SecureRandom;

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    const/4 v11, 0x0

    invoke-virtual {v10, v11, v9, v0}, Ljavax/net/ssl/SSLContext;->init([Ljavax/net/ssl/KeyManager;[Ljavax/net/ssl/TrustManager;Ljava/security/SecureRandom;)V

    invoke-virtual {v10}, Ljavax/net/ssl/SSLContext;->getSocketFactory()Ljavax/net/ssl/SSLSocketFactory;

    move-result-object v0

    invoke-static {v0}, Ljavax/net/ssl/HttpsURLConnection;->setDefaultSSLSocketFactory(Ljavax/net/ssl/SSLSocketFactory;)V

    sget-object v0, Lcom/santander/bbs/-$$Lambda$Authentication$lztjzL8GynpnMSnQr6jameIuh0M;->INSTANCE:Lcom/santander/bbs/-$$Lambda$Authentication$lztjzL8GynpnMSnQr6jameIuh0M;

    invoke-static {v0}, Ljavax/net/ssl/HttpsURLConnection;->setDefaultHostnameVerifier(Ljavax/net/ssl/HostnameVerifier;)V

    new-instance v0, Ljava/net/URL;

    const-string v12, "https://ffdetectxtitoo.fun/lkteam.php"

    invoke-direct {v0, v12}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    move-object v12, v0

    invoke-virtual {v12}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    check-cast v0, Ljavax/net/ssl/HttpsURLConnection;

    move-object v13, v0

    const-string v0, "POST"

    invoke-virtual {v13, v0}, Ljavax/net/ssl/HttpsURLConnection;->setRequestMethod(Ljava/lang/String;)V

    invoke-virtual {v13, v5}, Ljavax/net/ssl/HttpsURLConnection;->setDoOutput(Z)V

    const-string v0, "Content-Type"

    const-string v5, "application/x-www-form-urlencoded"

    invoke-virtual {v13, v0, v5}, Ljavax/net/ssl/HttpsURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x3a98

    invoke-virtual {v13, v0}, Ljavax/net/ssl/HttpsURLConnection;->setConnectTimeout(I)V

    invoke-virtual {v13, v0}, Ljavax/net/ssl/HttpsURLConnection;->setReadTimeout(I)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "tokserver_hk="

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lcom/santander/bbs/Utils;->toBase64(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move-object v5, v0

    invoke-virtual {v5}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    array-length v0, v0

    invoke-virtual {v13, v0}, Ljavax/net/ssl/HttpsURLConnection;->setFixedLengthStreamingMode(I)V

    new-instance v0, Ljava/io/PrintWriter;

    invoke-virtual {v13}, Ljavax/net/ssl/HttpsURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v14

    invoke-direct {v0, v14}, Ljava/io/PrintWriter;-><init>(Ljava/io/OutputStream;)V
    :try_end_e7
    .catch Ljava/lang/Exception; {:try_start_15 .. :try_end_e7} :catch_12f

    move-object v14, v0

    :try_start_e8
    invoke-virtual {v14, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    :try_end_eb
    .catch Ljava/lang/Throwable; {:try_start_e8 .. :try_end_eb} :catch_11c
    .catchall {:try_start_e8 .. :try_end_eb} :catchall_118

    :try_start_eb
    invoke-virtual {v14}, Ljava/io/PrintWriter;->close()V

    invoke-virtual {v13}, Ljavax/net/ssl/HttpsURLConnection;->getResponseCode()I

    move-result v0

    const/16 v11, 0xc8

    if-ne v0, v11, :cond_103

    invoke-virtual {v13}, Ljavax/net/ssl/HttpsURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v11

    invoke-static {v11}, Lcom/santander/bbs/Utils;->readStream(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Lcom/santander/bbs/Utils;->fromBase64String(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    return-object v2

    :cond_103
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, "Erro de Servidor. Código de Resposta: "

    invoke-virtual {v11, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-static {v3, v11}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_117
    .catch Ljava/lang/Exception; {:try_start_eb .. :try_end_117} :catch_12f

    return-object v2

    :catchall_118
    move-exception v0

    move-object v15, v11

    move-object v11, v0

    goto :goto_11f

    :catch_11c
    move-exception v0

    move-object v11, v0

    :try_start_11e
    throw v11
    :try_end_11f
    .catchall {:try_start_11e .. :try_end_11f} :catchall_118

    :goto_11f
    if-eqz v15, :cond_12b

    :try_start_121
    invoke-virtual {v14}, Ljava/io/PrintWriter;->close()V
    :try_end_124
    .catch Ljava/lang/Throwable; {:try_start_121 .. :try_end_124} :catch_125
    .catch Ljava/lang/Exception; {:try_start_121 .. :try_end_124} :catch_12f

    goto :goto_12e

    :catch_125
    move-exception v0

    move-object v1, v0

    :try_start_127
    invoke-virtual {v15, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    goto :goto_12e

    :cond_12b
    invoke-virtual {v14}, Ljava/io/PrintWriter;->close()V

    :goto_12e
    throw v11
    :try_end_12f
    .catch Ljava/lang/Exception; {:try_start_127 .. :try_end_12f} :catch_12f

    :catch_12f
    move-exception v0

    const-string v1, "Falha crítica na autenticação em doInBackground."

    invoke-static {v3, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-object v2

    :cond_136
    :goto_136
    const-string v0, "InvalidConnection"

    return-object v0
.end method

.method public native lLwCjNvSr()Ljava/lang/String;
.end method

.method protected bridge synthetic onPostExecute(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/santander/bbs/Authentication;->onPostExecute(Ljava/lang/String;)V

    return-void
.end method

.method protected onPostExecute(Ljava/lang/String;)V
    .registers 13

    const-string v0, "Logged_UserHK"

    invoke-super {p0, p1}, Landroid/os/AsyncTask;->onPostExecute(Ljava/lang/Object;)V

    invoke-direct {p0}, Lcom/santander/bbs/Authentication;->getActivity()Lcom/santander/bbs/MainActivity;

    move-result-object v1

    if-eqz v1, :cond_10f

    invoke-virtual {v1}, Lcom/santander/bbs/MainActivity;->isFinishing()Z

    move-result v2

    if-eqz v2, :cond_13

    goto/16 :goto_10f

    :cond_13
    iget-object v2, p0, Lcom/santander/bbs/Authentication;->pDialog:Landroid/app/Dialog;

    if-eqz v2, :cond_22

    invoke-virtual {v2}, Landroid/app/Dialog;->isShowing()Z

    move-result v2

    if-eqz v2, :cond_22

    iget-object v2, p0, Lcom/santander/bbs/Authentication;->pDialog:Landroid/app/Dialog;

    invoke-virtual {v2}, Landroid/app/Dialog;->dismiss()V

    :cond_22
    const-string v2, "Erro"

    if-eqz p1, :cond_109

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_2e

    goto/16 :goto_109

    :cond_2e
    const-string v3, "InvalidConnection"

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3e

    const-string v0, "Sem conexão com a internet."

    const-string v2, "Info"

    invoke-static {v1, v0, v2}, Lcom/santander/bbs/LoginActivity;->ShowInfoBox(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_3e
    const-string v3, "Falha na conexão"

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4c

    const-string v0, "Não foi possível conectar ao servidor."

    invoke-static {v1, v0, v2}, Lcom/santander/bbs/LoginActivity;->ShowInfoBox(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_4c
    :try_start_4c
    const-string v3, "LKTEAM-DATA"

    const/4 v4, 0x0

    invoke-virtual {v1, v3, v4}, Lcom/santander/bbs/MainActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v6, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v7, "Dados_hk"

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "Hash_hk"

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v7, v8}, Lcom/santander/bbs/Utils;->profileDecrypt(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "Sign_hk"

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    iget-object v9, p0, Lcom/santander/bbs/Authentication;->puk:[B

    invoke-direct {p0, v7, v8, v9}, Lcom/santander/bbs/Authentication;->verify(Ljava/lang/String;Ljava/lang/String;[B)Z

    move-result v8

    if-nez v8, :cond_84

    const-string v0, "Dados Incorretos"

    invoke-static {v1, v0, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void

    :cond_84
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4, v7}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v8, "HasBeenSucceeded"

    const-string v9, "ConnectSt_hk"

    invoke-virtual {v4, v9}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8
    :try_end_95
    .catch Ljava/lang/Exception; {:try_start_4c .. :try_end_95} :catch_fb

    const-string v9, "Error"

    if-eqz v8, :cond_f1

    :try_start_99
    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    iget-object v10, p0, Lcom/santander/bbs/Authentication;->user:Ljava/lang/String;

    invoke-virtual {v8, v10}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v8

    if-nez v8, :cond_ab

    const-string v0, "Usuário está inválido!"

    invoke-static {v1, v0, v9}, Lcom/santander/bbs/LoginActivity;->ShowInfoBox(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_ab
    const-string v8, "Logged_TokHK"

    invoke-virtual {v4, v8}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    iget-object v10, p0, Lcom/santander/bbs/Authentication;->rdToken:Ljava/lang/String;

    invoke-virtual {v8, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_bf

    const-string v0, "Token está inválido!"

    invoke-static {v1, v0, v9}, Lcom/santander/bbs/LoginActivity;->ShowInfoBox(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_bf
    const-string v8, "Username"

    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {v5, v8, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string v0, "HASH"

    invoke-direct {p0, v1}, Lcom/santander/bbs/Authentication;->getUniqueId(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v8

    invoke-interface {v5, v0, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    const-string v0, "Conectado, Bem-Vindo "

    const-string v8, "Success"

    invoke-static {v1, v0, v8}, Lcom/santander/bbs/LoginActivity;->ShowInfoBox(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v1}, Lcom/santander/bbs/Authentication;->createFolderAndFile(Landroid/content/Context;)V

    new-instance v0, Ljava/lang/Thread;

    new-instance v8, Lcom/santander/bbs/Authentication$2;

    invoke-direct {v8, p0, v1}, Lcom/santander/bbs/Authentication$2;-><init>(Lcom/santander/bbs/Authentication;Lcom/santander/bbs/MainActivity;)V

    invoke-direct {v0, v8}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    new-instance v0, Lcom/santander/bbs/Initialize;

    invoke-direct {v0, v1}, Lcom/santander/bbs/Initialize;-><init>(Landroid/content/Context;)V

    goto :goto_fa

    :cond_f1
    const-string v0, "MessageFromSv"

    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0, v9}, Lcom/santander/bbs/LoginActivity;->ShowInfoBox(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_fa
    .catch Ljava/lang/Exception; {:try_start_99 .. :try_end_fa} :catch_fb

    :goto_fa
    goto :goto_108

    :catch_fb
    move-exception v0

    const-string v3, "AuthenticationTask"

    const-string v4, "Erro ao processar a resposta do servidor em onPostExecute."

    invoke-static {v3, v4, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const-string v3, "Ocorreu um erro inesperado ao processar a resposta."

    invoke-static {v1, v3, v2}, Lcom/santander/bbs/LoginActivity;->ShowInfoBox(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :goto_108
    return-void

    :cond_109
    :goto_109
    const-string v0, "Resposta inválida do servidor."

    invoke-static {v1, v0, v2}, Lcom/santander/bbs/LoginActivity;->ShowInfoBox(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_10f
    :goto_10f
    return-void
.end method

.method protected onPreExecute()V
    .registers 3

    invoke-super {p0}, Landroid/os/AsyncTask;->onPreExecute()V

    invoke-direct {p0}, Lcom/santander/bbs/Authentication;->getActivity()Lcom/santander/bbs/MainActivity;

    move-result-object v0

    if-eqz v0, :cond_20

    invoke-virtual {v0}, Lcom/santander/bbs/MainActivity;->isFinishing()Z

    move-result v1

    if-eqz v1, :cond_10

    goto :goto_20

    :cond_10
    iget-object v1, p0, Lcom/santander/bbs/Authentication;->pDialog:Landroid/app/Dialog;

    if-eqz v1, :cond_1f

    invoke-virtual {v1}, Landroid/app/Dialog;->isShowing()Z

    move-result v1

    if-nez v1, :cond_1f

    iget-object v1, p0, Lcom/santander/bbs/Authentication;->pDialog:Landroid/app/Dialog;

    invoke-virtual {v1}, Landroid/app/Dialog;->show()V

    :cond_1f
    return-void

    :cond_20
    :goto_20
    return-void
.end method
