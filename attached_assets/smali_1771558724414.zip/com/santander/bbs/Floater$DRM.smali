.class Lcom/santander/bbs/Floater$DRM;
.super Ljava/util/TimerTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/santander/bbs/Floater;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "DRM"
.end annotation


# static fields
.field private static final USER:Ljava/lang/String; = "USER"


# instance fields
.field private final puk:[B

.field final synthetic this$0:Lcom/santander/bbs/Floater;


# direct methods
.method constructor <init>(Lcom/santander/bbs/Floater;)V
    .registers 3

    iput-object p1, p0, Lcom/santander/bbs/Floater$DRM;->this$0:Lcom/santander/bbs/Floater;

    invoke-direct {p0}, Ljava/util/TimerTask;-><init>()V

    const/16 v0, 0xa2

    new-array v0, v0, [B

    fill-array-data v0, :array_10

    iput-object v0, p0, Lcom/santander/bbs/Floater$DRM;->puk:[B

    return-void

    nop

    :array_10
    .array-data 1
        0x30t
        -0x7ft
        -0x61t
        0x30t
        0xdt
        0x6t
        0x9t
        0x2at
        -0x7at
        0x48t
        -0x7at
        -0x9t
        0xdt
        0x1t
        0x1t
        0x1t
        0x5t
        0x0t
        0x3t
        -0x7ft
        -0x73t
        0x0t
        0x30t
        -0x7ft
        -0x77t
        0x2t
        -0x7ft
        -0x7ft
        0x0t
        -0x22t
        -0x19t
        -0x6et
        -0x6at
        -0x51t
        0x21t
        -0x23t
        0x29t
        -0x55t
        -0x53t
        -0x31t
        -0x77t
        -0x76t
        0x4bt
        0x6ft
        -0x79t
        0x9t
        -0x1dt
        -0x18t
        0x6ct
        0x1bt
        -0x70t
        -0x1dt
        0x3at
        -0x3ft
        0x22t
        0x1et
        0x2ct
        0x35t
        -0x46t
        0xdt
        0x38t
        -0x52t
        -0x73t
        -0xet
        -0x71t
        0x25t
        0xdt
        -0x61t
        0x5ct
        -0x1ct
        0x1dt
        0x52t
        0xct
        0x52t
        -0x6et
        0x2et
        0x18t
        -0x39t
        -0x6dt
        -0x5ct
        -0x1bt
        -0x2ft
        -0x25t
        -0x6ct
        -0x36t
        0x2t
        0x65t
        -0x64t
        0x1t
        0x7dt
        0x40t
        -0x6ft
        0x54t
        0x17t
        -0x7at
        0x1ct
        -0x2dt
        -0x27t
        0x33t
        -0x1bt
        0x40t
        0x1t
        0x78t
        0x4dt
        -0x6bt
        0x6at
        0x63t
        -0x52t
        0x3dt
        0x71t
        0x0t
        0x7dt
        -0x3at
        0x70t
        -0x34t
        -0x64t
        0x1t
        -0x23t
        -0x72t
        -0x6et
        -0x25t
        -0x11t
        -0x37t
        -0x34t
        -0x65t
        0x53t
        0x49t
        0x6bt
        -0x47t
        0x3dt
        0x39t
        -0x15t
        0x7bt
        0x6ct
        -0x63t
        0x4et
        0x3at
        -0x7dt
        0x50t
        -0x7ft
        -0x1dt
        -0x70t
        0x16t
        -0x14t
        0x59t
        0x39t
        -0x22t
        -0x15t
        -0x40t
        -0x66t
        -0x16t
        0x5dt
        0x5at
        0x5bt
        -0x22t
        0x5ft
        0x1dt
        0x2t
        0x3t
        0x1t
        0x0t
        0x1t
    .end array-data
.end method

.method static synthetic lambda$showToast$0(Ljava/lang/String;)V
    .registers 3

    invoke-static {}, Lcom/santander/bbs/Floater;->access$400()Landroid/content/Context;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v0, p0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private processServerResponse(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 9

    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-static {p1}, Lcom/santander/bbs/Utils;->fromBase64String(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v1, "Dados_hk"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "Hash_hk"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/santander/bbs/Utils;->profileDecrypt(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "Sign_hk"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Lcom/santander/bbs/Floater$DRM;->puk:[B

    invoke-static {v1, v2, v3}, Lcom/santander/bbs/RSA;->verify(Ljava/lang/String;Ljava/lang/String;[B)Z

    move-result v2

    if-nez v2, :cond_39

    const-string v2, "Login Data is Wrong!"

    invoke-direct {p0, v2}, Lcom/santander/bbs/Floater$DRM;->showToast(Ljava/lang/String;)V

    return-void

    :cond_39
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v3, "HasBeenSucceeded"

    const-string v4, "ConnectSt_hk"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_54

    invoke-direct {p0, v2, p2, p3}, Lcom/santander/bbs/Floater$DRM;->validateUserData(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_68

    :cond_54
    const-string v3, "MessageFromSv"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {p0, v3}, Lcom/santander/bbs/Floater$DRM;->showToast(Ljava/lang/String;)V

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v3

    invoke-static {v3}, Landroid/os/Process;->killProcess(I)V
    :try_end_68
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_68} :catch_69

    :goto_68
    goto :goto_85

    :catch_69
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Erro ao processar resposta do servidor: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/santander/bbs/Floater$DRM;->showToast(Ljava/lang/String;)V

    :goto_85
    return-void
.end method

.method private showToast(Ljava/lang/String;)V
    .registers 4

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lcom/santander/bbs/-$$Lambda$Floater$DRM$S23MLyYD5aAsMaftN48GekQi-RA;

    invoke-direct {v1, p1}, Lcom/santander/bbs/-$$Lambda$Floater$DRM$S23MLyYD5aAsMaftN48GekQi-RA;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private validateUserData(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/InterruptedException;,
            Lorg/json/JSONException;
        }
    .end annotation

    const-string v0, "Logged_UserHK"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, p3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_12

    const-string v0, "Usuário inválido"

    invoke-direct {p0, v0}, Lcom/santander/bbs/Floater$DRM;->showToast(Ljava/lang/String;)V

    return-void

    :cond_12
    const-string v0, "Logged_TokHK"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_24

    const-string v0, "Token está inválido!"

    invoke-direct {p0, v0}, Lcom/santander/bbs/Floater$DRM;->showToast(Ljava/lang/String;)V

    return-void

    :cond_24
    invoke-static {}, Lcom/santander/bbs/Floater;->access$600()Z

    move-result v0

    if-nez v0, :cond_33

    const-wide/16 v0, 0x1450

    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V

    const/4 v0, 0x1

    invoke-static {v0}, Lcom/santander/bbs/Floater;->access$602(Z)Z

    :cond_33
    return-void
.end method


# virtual methods
.method public run()V
    .registers 13

    invoke-static {}, Lcom/santander/bbs/Floater;->access$400()Landroid/content/Context;

    move-result-object v0

    const-string v1, "LKTEAM-DATA"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "Username"

    const-string v2, ""

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Lcom/santander/bbs/Floater;->rdStr()Ljava/lang/String;

    move-result-object v2

    :try_start_17
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Thread;->isInterrupted()Z

    move-result v3

    if-eqz v3, :cond_22

    return-void

    :cond_22
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    const-string v5, "User_hk"

    invoke-virtual {v4, v5, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v5, "jofjofjoe"

    const-string v6, "9"

    invoke-virtual {v4, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v5, "Uid_hk"

    iget-object v6, p0, Lcom/santander/bbs/Floater$DRM;->this$0:Lcom/santander/bbs/Floater;

    invoke-static {}, Lcom/santander/bbs/Floater;->access$400()Landroid/content/Context;

    move-result-object v7

    invoke-static {v6, v7}, Lcom/santander/bbs/Floater;->access$500(Lcom/santander/bbs/Floater;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-static {}, Lcom/santander/bbs/Floater;->getPublicIpAddress()Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_fb

    const-string v6, "Unavailable"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_57

    goto/16 :goto_fb

    :cond_57
    const-string v6, "Ip_hk"

    invoke-virtual {v4, v6, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v6, "Tok_hk"

    invoke-virtual {v3, v6, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v6, "Dados_hk"

    invoke-virtual {v4}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v7

    iget-object v8, p0, Lcom/santander/bbs/Floater$DRM;->puk:[B

    invoke-static {v7, v8}, Lcom/santander/bbs/RSA;->encrypt(Ljava/lang/String;[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v6, "Hash_hk"

    invoke-virtual {v4}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lcom/santander/bbs/Utils;->SHA256(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-instance v6, Ljava/net/URL;

    iget-object v7, p0, Lcom/santander/bbs/Floater$DRM;->this$0:Lcom/santander/bbs/Floater;

    const-string v7, "https://ffdetectxtitoo.fun/lkteam.php"

    invoke-direct {v6, v7}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v6

    check-cast v6, Ljava/net/HttpURLConnection;

    const-string v7, "POST"

    invoke-virtual {v6, v7}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Ljava/net/HttpURLConnection;->setDoOutput(Z)V

    const-string v7, "Content-Type"

    const-string v8, "application/x-www-form-urlencoded"

    invoke-virtual {v6, v7, v8}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "tokserver_hk="

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Lcom/santander/bbs/Utils;->toBase64(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->getBytes()[B

    move-result-object v8

    array-length v8, v8

    invoke-virtual {v6, v8}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    new-instance v8, Ljava/io/PrintWriter;

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v9

    invoke-direct {v8, v9}, Ljava/io/PrintWriter;-><init>(Ljava/io/OutputStream;)V
    :try_end_c6
    .catch Ljava/lang/Exception; {:try_start_17 .. :try_end_c6} :catch_101

    const/4 v9, 0x0

    :try_start_c7
    invoke-virtual {v8, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    :try_end_ca
    .catch Ljava/lang/Throwable; {:try_start_c7 .. :try_end_ca} :catch_ea
    .catchall {:try_start_c7 .. :try_end_ca} :catchall_e8

    :try_start_ca
    invoke-virtual {v8}, Ljava/io/PrintWriter;->close()V

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v8

    invoke-static {v8}, Lcom/santander/bbs/Utils;->readStream(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_e2

    invoke-direct {p0, v8, v2, v1}, Lcom/santander/bbs/Floater$DRM;->processServerResponse(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_e7

    :cond_e2
    const-string v9, "Ocorreu um erro no Servidor!"

    invoke-direct {p0, v9}, Lcom/santander/bbs/Floater$DRM;->showToast(Ljava/lang/String;)V
    :try_end_e7
    .catch Ljava/lang/Exception; {:try_start_ca .. :try_end_e7} :catch_101

    :goto_e7
    goto :goto_11d

    :catchall_e8
    move-exception v10

    goto :goto_ec

    :catch_ea
    move-exception v9

    :try_start_eb
    throw v9
    :try_end_ec
    .catchall {:try_start_eb .. :try_end_ec} :catchall_e8

    :goto_ec
    if-eqz v9, :cond_f7

    :try_start_ee
    invoke-virtual {v8}, Ljava/io/PrintWriter;->close()V
    :try_end_f1
    .catch Ljava/lang/Throwable; {:try_start_ee .. :try_end_f1} :catch_f2
    .catch Ljava/lang/Exception; {:try_start_ee .. :try_end_f1} :catch_101

    goto :goto_fa

    :catch_f2
    move-exception v11

    :try_start_f3
    invoke-virtual {v9, v11}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    goto :goto_fa

    :cond_f7
    invoke-virtual {v8}, Ljava/io/PrintWriter;->close()V

    :goto_fa
    throw v10

    :cond_fb
    :goto_fb
    const-string v6, "No internet access!"

    invoke-direct {p0, v6}, Lcom/santander/bbs/Floater$DRM;->showToast(Ljava/lang/String;)V
    :try_end_100
    .catch Ljava/lang/Exception; {:try_start_f3 .. :try_end_100} :catch_101

    return-void

    :catch_101
    move-exception v3

    invoke-virtual {v3}, Ljava/lang/Exception;->printStackTrace()V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Erro interno no servidor: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {p0, v4}, Lcom/santander/bbs/Floater$DRM;->showToast(Ljava/lang/String;)V

    :goto_11d
    return-void
.end method
